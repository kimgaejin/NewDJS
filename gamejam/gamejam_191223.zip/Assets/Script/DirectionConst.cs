﻿public class DirectionConst
{
    public enum Direction
    {
        Up, Down, Left, Right
            , LeftUp, LeftDown, RightUp, RightDown
    }
}