﻿using UnityEngine;
// 그냥 필요한 코드
[System.Serializable]
public class ColorToPrefeb {
    public Color color;
    public GameObject prefab;
	
}
